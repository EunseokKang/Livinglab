from django.apps import AppConfig


class BellSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bell_system'
